Darshit AC website package

Put these original images inside the assets folder:
logo.jpg
ac-repair-1.jpg
ac-repair-2.jpg
ac-service-1.jpg
ac-service-2.jpg
ac-service-3.jpg
tools.jpg

Then upload the complete folder to your hosting. For Google Ads, use the public HTTPS homepage as the Final URL.
